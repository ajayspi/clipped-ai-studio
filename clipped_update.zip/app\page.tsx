"use client";

import Link from "next/link";
import { Video, Zap, Shield, ExternalLink, Play, Sparkles, Wand2, Rocket } from "lucide-react";
import { Particles } from "@/components/ui/particles";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col bg-black text-white overflow-hidden selection:bg-primary/30">
      
      {/* Absolute Backgrounds */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent z-20" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-transparent z-20" />
        <img 
          src="/hero-bg.jpg" 
          alt="Cinematic abstract AI nodes" 
          className="w-full h-full object-cover opacity-60"
        />
        <Particles className="z-30 opacity-70" />
      </div>

      {/* Navbar */}
      <header className="relative z-50 border-b border-white/10 bg-black/20 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl tracking-tight text-white">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shadow-lg shadow-primary/20">
              <Video className="h-4 w-4 text-white" />
            </div>
            Clipped
          </Link>
          <nav className="flex items-center gap-6">
            <Link href="/login" className="text-sm font-medium text-white/70 hover:text-white transition-colors">
              Login
            </Link>
            <Link
              href="/register"
              className="inline-flex items-center justify-center rounded-full bg-white px-5 py-2.5 text-sm font-bold text-black shadow-lg hover:bg-white/90 transition-all hover:scale-105 active:scale-95"
            >
              Start Creating
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <main className="relative z-40 flex flex-1 flex-col items-center justify-center text-center px-4 py-32 sm:py-48">
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 backdrop-blur-md px-4 py-1.5 text-xs font-medium text-white/80 mb-8 shadow-2xl"
        >
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          The Open-Source AI Video Studio
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.1, ease: "easeOut" }}
          className="max-w-4xl text-5xl font-extrabold tracking-tight sm:text-7xl lg:text-8xl text-transparent bg-clip-text bg-gradient-to-b from-white to-white/60 pb-2 drop-shadow-sm"
        >
          Clip ideas into <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-purple-400 to-blue-500 animate-gradient-x">
            viral videos.
          </span>
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
          className="mt-8 max-w-2xl text-lg sm:text-xl text-white/60 leading-relaxed font-light"
        >
          Turn simple text prompts into polished short-form videos. Powered by 8 AI workflows, fully automated subtitles, and a 100% keyless fallback engine.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
          className="mt-12 flex flex-col sm:flex-row gap-5 items-center justify-center"
        >
          <Link
            href="/create/auto"
            className="group relative inline-flex items-center justify-center overflow-hidden rounded-full bg-gradient-to-r from-primary to-purple-600 px-8 py-4 text-base font-bold text-white shadow-xl shadow-primary/20 transition-all hover:scale-105 active:scale-95"
          >
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
            <Wand2 className="mr-2 h-5 w-5" />
            Try Auto-Pilot
          </Link>
          
          <Link
            href="/dashboard"
            className="inline-flex items-center justify-center rounded-full border border-white/20 bg-white/5 backdrop-blur-md px-8 py-4 text-base font-medium text-white shadow-lg transition-all hover:bg-white/10 hover:scale-105 active:scale-95"
          >
            <Play className="mr-2 h-5 w-5 fill-white/20" />
            View Gallery
          </Link>
        </motion.div>

        {/* Feature Highlights */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6, ease: "easeOut" }}
          className="mt-32 grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-5xl mx-auto w-full px-6"
        >
          {[
            { icon: Zap, title: "100% Keyless Mode", desc: "No API keys needed. Fallbacks gracefully use free open-source models." },
            { icon: Wand2, title: "Hormozi Captions", desc: "Dynamic word-by-word highlighted subtitles powered by Remotion physics." },
            { icon: Rocket, title: "Multi-Format", desc: "Export effortlessly to TikTok (9:16), YouTube (16:9), or Instagram (1:1)." },
          ].map((feat, i) => (
            <div key={i} className="flex flex-col items-center text-center p-6 rounded-2xl bg-white/[0.03] border border-white/5 backdrop-blur-sm transition-colors hover:bg-white/[0.05]">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mb-4 text-primary">
                <feat.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">{feat.title}</h3>
              <p className="text-sm text-white/50 leading-relaxed">{feat.desc}</p>
            </div>
          ))}
        </motion.div>
      </main>
    </div>
  );
}
